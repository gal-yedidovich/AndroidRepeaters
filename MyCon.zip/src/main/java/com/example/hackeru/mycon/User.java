package com.example.hackeru.mycon;

public class User {
    public final String name, phone;

    public User(String name, String phone) {
        this.name = name;
        this.phone = phone;
    }
}
